<?php
function devvn_customize_register($wp_customize) 
{
	//Footer
	$wp_customize->add_section("footer", array(
		'title' 		=> __("Footer", "devvn"),
		'priority' 		=> 130,
		'description' 	=> __( 'Description Custom footer here' ),
	));
	
	//Footer text
	$wp_customize->add_setting("footer_text", array(
		'default' 		=> '',
		'transport' 	=> 'postMessage',
	));	
	$wp_customize->add_control(new WP_Customize_Control($wp_customize,"footer_text",array(
		'label' 		=> __("Footer text here", "devvn"),
		'section' 		=> 'footer',
		'settings' 		=> 'footer_text',
		'type' 			=> 'textarea',
	)));
	
	//Footer background color
	$wp_customize->add_setting("footer_bg_color", array(
		'default' 		=> '#ccc',
		'transport' 	=> 'postMessage',
	));	
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_bg_color', array(
		'label'   		=> 'Footer Background Color',
		'section' 		=> 'footer',
        'settings'   	=> 'footer_bg_color',

    )));
    
    //Footer text color
	$wp_customize->add_setting("footer_text_color", array(
		'default' 		=> '#000',
		'transport' 	=> 'postMessage',
	));	
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_text_color', array(
		'label'   		=> __('Footer Text Color', 'devvn'),
		'section' 		=> 'footer',
        'settings'   	=> 'footer_text_color',

    )));
    
    //Footer logo
	$wp_customize->add_setting("footer_logo", array(
		'transport' 	=> 'postMessage',
	));	
	$wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize,'footer_logo',array(
	 	'label'      	=> __('Footer Logo', 'devvn'),
	 	'section'    	=> 'footer',
	 	'settings'   	=> 'footer_logo',
	)));
}

add_action("customize_register","devvn_customize_register");

function devvn_customizer_live_preview(){
	wp_enqueue_script("devvn-themecustomizer", get_template_directory_uri() . "/theme_customize/theme-customizer.js", array("jquery", "customize-preview"), '',  true);
}
add_action("customize_preview_init", "devvn_customizer_live_preview");

function devvn_customize_control_js() {
	wp_enqueue_script( 'color-scheme-control', get_template_directory_uri() . '/theme_customize/color-scheme-control.js', array( 'customize-controls', 'iris', 'underscore', 'wp-util' ), '', true );
}
add_action( 'customize_controls_enqueue_scripts', 'devvn_customize_control_js' );


function devvn_get_color_scheme_css( $colors ) {
	$colors = wp_parse_args( $colors, array(
		'footer_bg_color'      	=>	'',
		'footer_text_color'		=>	''
	) );

	return <<<CSS
	footer.footer { background: {$colors['footer_bg_color']}; color: {$colors['footer_text_color']};}

CSS;
}

function devvn_color_scheme_css_template() {
	$colors = array(
		'footer_bg_color'      => '{{ data.footer_bg_color }}',	
		'footer_text_color'    => '{{ data.footer_text_color }}',		
	);
	?>
	<script type="text/html" id="tmpl-devvn-color-scheme">
		<?php echo devvn_get_color_scheme_css( $colors ); ?>
	</script>
	<?php
}
add_action( 'customize_controls_print_footer_scripts', 'devvn_color_scheme_css_template' );

function get_custom_style() {
	$options = get_theme_mods();
	?>
	<style type="text/css">
		footer.footer { background: <?php echo $options['footer_bg_color']; ?>;  color: <?php echo $options['footer_text_color']; ?>;}
	</style>
	<?php
}
add_action( 'wp_head', 'get_custom_style' );